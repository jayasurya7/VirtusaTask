package com.example.virginmoney.Api;

import com.example.virginmoney.Models.PeopleResult;
import com.example.virginmoney.Models.RoomsResult;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {
    @GET("/rooms/")
    Call<List<RoomsResult>> getRooms();

    @GET("/people/")
    Call<List<PeopleResult>> getPeople();
}
