package com.example.virginmoney

import android.content.ContentValues.TAG
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.virginmoney.Adapters.RoomsAdapter
import com.example.virginmoney.Api.ApiClient
import com.example.virginmoney.Api.ApiInterface
import com.example.virginmoney.databinding.FragmentRoomBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

import com.example.virginmoney.Models.RoomsResult


/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class RoomFragment : Fragment() {

    private var _binding: FragmentRoomBinding? = null

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<RoomsAdapter.ViewHolder>? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentRoomBinding.inflate(inflater, container, false)

        (activity as MainActivity).supportActionBar?.title = "Currently Occupied Rooms"

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.roomsListView.apply {
            // set a LinearLayoutManager to handle Android
            // RecyclerView behavior
            layoutManager = LinearLayoutManager(activity)
            binding.ProgressBar.setVisibility(View.VISIBLE);
            val apiService = ApiClient.getClient().create(
                ApiInterface::class.java)
            val roomsCall: Call<List<RoomsResult>> = apiService.getRooms()
            roomsCall.enqueue( object : Callback<List<RoomsResult>> {
                override fun onResponse(call: Call<List<RoomsResult>>?, response: Response<List<RoomsResult>>?) {
                    binding.ProgressBar.setVisibility(View.GONE);
                    var listData = fetchResults(response)

                    if (listData!!.size != 0) {
                        var listdata1: MutableList<RoomsResult> = ArrayList<RoomsResult>()
                        for (b in listData.indices) {
                            if(listData.get(b).isOccupied == true){
                                listdata1.add(listData.get(b))
                            }
                        }

                        val context = context as MainActivity
                        adapter = RoomsAdapter(context, listdata1)
                    }

                }

                override fun onFailure(call: Call<List<RoomsResult>>?, t: Throwable?) {
                    Log.e(TAG, "parsing - onFailure() ", t)

                }

            })

        }

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    private fun fetchResults(response: Response<List<RoomsResult>>?) = response!!.body()

}