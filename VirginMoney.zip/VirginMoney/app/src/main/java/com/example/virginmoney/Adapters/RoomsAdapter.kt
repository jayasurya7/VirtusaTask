package com.example.virginmoney.Adapters

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.example.virginmoney.Models.RoomsResult
import com.example.virginmoney.R

/**
 * Created by TejaReddy on 17/11/17.
 */
class RoomsAdapter(private val context: Context, private val roomsList: List<RoomsResult>) :
    RecyclerView.Adapter<RoomsAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val roomItem = LayoutInflater.from(parent.context)
            .inflate(R.layout.room_item, parent, false) as LinearLayout
        return ViewHolder(roomItem)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.updateWithViewHolder(roomsList[position])
    }

    override fun getItemCount(): Int {
        return roomsList.count();
    }


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        private var view: View = itemView
        private var roomsResult: RoomsResult? = null

        //3
        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            val context = itemView.context
        }

        private val room_id: TextView = itemView.findViewById(R.id.room_id)
        private val createdAt: TextView = itemView.findViewById(R.id.createdAt)
        private val isOccupied: TextView = itemView.findViewById(R.id.isOccupied)
        private val maxOccupancy: TextView = itemView.findViewById(R.id.maxOccupancy)

        fun updateWithViewHolder(room: RoomsResult) {
            this.roomsResult = room
            val context = itemView.context
            room_id.setText("User ID : "+android.text.Html.fromHtml(room.id))
            createdAt.setText("Created : "+android.text.Html.fromHtml(room.createdAt))
            isOccupied.setText("Occupied : "+android.text.Html.fromHtml(room.isOccupied.toString()))
            maxOccupancy.setText("MaxOccupancy : "+android.text.Html.fromHtml(room.maxOccupancy.toString()))

        }
    }
}