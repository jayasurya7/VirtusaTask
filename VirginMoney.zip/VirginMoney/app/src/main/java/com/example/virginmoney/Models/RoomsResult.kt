package com.example.virginmoney.Models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Created by tejareddy on 03/01/18.
 */
public class RoomsResult : Serializable {
    @SerializedName("createdAt")
    lateinit var createdAt: String

    @SerializedName("isOccupied")
    var isOccupied: Boolean = true

    @SerializedName("maxOccupancy")
    var maxOccupancy: Int = 0

    @SerializedName("id")
    lateinit var id: String
}