package com.example.virginmoney

import android.content.ContentValues
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.virginmoney.Adapters.PeopleAdapter
import com.example.virginmoney.Models.PeopleResult
import com.example.virginmoney.databinding.FragmentPeopleBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.example.virginmoney.Api.ApiClient
import com.example.virginmoney.Api.ApiInterface
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*


/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class PeopleFragment : Fragment() {

    private var _binding: FragmentPeopleBinding? = null

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<PeopleAdapter.ViewHolder>? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentPeopleBinding.inflate(inflater, container, false)
        (activity as MainActivity).supportActionBar?.title = "Colleagues"

        (activity as MainActivity).toolbar.roomButton.visibility = View.VISIBLE

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.peopleRecyclerView.apply {
            // set a LinearLayoutManager to handle Android
            // RecyclerView behavior
            layoutManager = LinearLayoutManager(activity)


            binding.ProgressBar.setVisibility(View.VISIBLE);
            val apiService = ApiClient.getClient().create(
                ApiInterface::class.java)
            val peopleCall: Call<List<PeopleResult>> = apiService.getPeople()
            peopleCall.enqueue( object : Callback<List<PeopleResult>> {
                override fun onResponse(call: Call<List<PeopleResult>>?, response: Response<List<PeopleResult>>?) {
                    binding.ProgressBar.setVisibility(View.GONE);

                    var listData = fetchResults(response)

                    if (listData!!.size != 0) {
                        val context = context as MainActivity
                        adapter = PeopleAdapter(context, listData)
                    }

                }

                override fun onFailure(call: Call<List<PeopleResult>>?, t: Throwable?) {
                    Log.e(ContentValues.TAG, "parsing - onFailure() ", t)

                }

            })

        }

//        binding.buttonFirst.setOnClickListener {
//            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
//        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun fetchResults(response: Response<List<PeopleResult>>?) = response!!.body()

}