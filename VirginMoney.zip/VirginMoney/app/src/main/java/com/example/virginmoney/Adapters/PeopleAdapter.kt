package com.example.virginmoney.Adapters

import android.content.Context
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.virginmoney.Models.PeopleResult
import com.example.virginmoney.R

/**
 * Created by TejaReddy on 17/11/17.
 */
class PeopleAdapter(private val context: Context, private val peopleList: List<PeopleResult>) :
    RecyclerView.Adapter<PeopleAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val peopleItem = LayoutInflater.from(parent.context)
            .inflate(R.layout.people_item, parent, false) as LinearLayout
        return ViewHolder(peopleItem)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.updateWithViewHolder(peopleList[position])
    }

    override fun getItemCount(): Int {
        return peopleList.count();
    }


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        private var view: View = itemView
        private var PeopleResult: PeopleResult? = null

        //3
        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            val context = itemView.context
            var clickedItem = this.PeopleResult;
            var navController: NavController? = null

//                peopleList!![adapterPosition];

            val bundle = Bundle()
            bundle.putSerializable("data", clickedItem)

            Navigation.findNavController(view).navigate(R.id.action_FirstFragment_to_DetailFragment, bundle)

            Toast.makeText(context, adapterPosition.toString(), 10 as Int).show()

        }

        private val nametLine: TextView = itemView.findViewById(R.id.nametLine)
        private val jobLine: TextView = itemView.findViewById(R.id.jobLine)
        private val cratedLine: TextView = itemView.findViewById(R.id.cratedLine)
        private val icon: ImageView = itemView.findViewById(R.id.icon)

        fun updateWithViewHolder(people: PeopleResult) {
            this.PeopleResult = people
            val context = itemView.context
            nametLine.setText(android.text.Html.fromHtml(people.firstName+ " " +people.lastName))
            jobLine.setText(android.text.Html.fromHtml(people.jobtitle))
            cratedLine.setText(android.text.Html.fromHtml(people.createdAt))
//            icon.setText("Name : "+android.text.Html.fromHtml(people.firstName+people.lastName))

            Glide.with(context)
                .load(people.avatar)
                .placeholder(R.drawable.ic_launcher_background)
                .diskCacheStrategy(DiskCacheStrategy.ALL)   // cache both original & resized image
                .centerCrop()
                .into(icon)
        }
    }
}