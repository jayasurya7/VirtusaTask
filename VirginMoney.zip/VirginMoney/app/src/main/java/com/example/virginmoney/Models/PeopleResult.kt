package com.example.virginmoney.Models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Created by tejareddy on 03/01/18.
 */
public class PeopleResult : Serializable {
    @SerializedName("createdAt")
    lateinit var createdAt: String

    @SerializedName("firstName")
    lateinit var firstName: String

    @SerializedName("avatar")
    lateinit var avatar: String

    @SerializedName("lastName")
    lateinit var lastName: String

    @SerializedName("email")
    lateinit var email: String

    @SerializedName("jobtitle")
    lateinit var jobtitle: String

    @SerializedName("favouriteColor")
    lateinit var favouriteColor: String

    @SerializedName("id")
    lateinit var id: String
}