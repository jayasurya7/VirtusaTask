package com.example.virginmoney

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.virginmoney.Models.PeopleResult
import com.example.virginmoney.databinding.FragmentDetailBinding
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*


/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class DetailFragment : Fragment() {

    private var _binding: FragmentDetailBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentDetailBinding.inflate(inflater, container, false)

        (activity as MainActivity).supportActionBar?.title = "Colleague Contact Details"
        (activity as MainActivity).toolbar.roomButton.visibility = View.GONE

        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var retriveItem = this.arguments?.getSerializable("data") as PeopleResult

//        Log.d("retriveItem", retriveItem.toString())

        Glide.with(context)
            .load(retriveItem.avatar)
            .placeholder(com.example.virginmoney.R.drawable.ic_launcher_background)
            .diskCacheStrategy(DiskCacheStrategy.ALL)   // cache both original & resized image
            .centerCrop()
            .into(binding.peopleAvatar)

        binding.peopleId.setText("User ID : "+retriveItem.id)
        binding.peopleName.setText("Full Name : "+retriveItem.firstName+" "+retriveItem.lastName)
        binding.peopleJob.setText("Job : "+retriveItem.jobtitle)
        binding.peopleCreated.setText("Created : "+retriveItem.createdAt)
        binding.peopleEmail.setText("Email : "+retriveItem.email)
        binding.peopleFavColor.setText("Favourite Color : "+retriveItem.favouriteColor)


//        Toast.makeText(context, retriveItem.toString(), 10 as Int).show()

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}